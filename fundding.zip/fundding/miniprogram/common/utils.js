let getNowFormatDate = function() {
    var date = new Date()
    var year = date.getFullYear()
    var month = date.getMonth() + 1
    var strDate = date.getDate()
    if (month >= 1 && month <= 9) {
        month = "0" + month
    }
    if (strDate >= 1 && strDate <= 9) {
        strDate = "0" + strDate
    }
    var current = year + '年' + month + '月'+ strDate + '日'
    return current
}
module.exports = {
    getNowFormatDate
}
